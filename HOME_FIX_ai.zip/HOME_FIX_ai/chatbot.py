# chatbot.py

def get_homefix_response(message):

    message = message.lower().strip()

    # ============================================================
    # AIR CONDITIONER
    # ============================================================

    if any(word in message for word in [
        "ac", "air conditioner", "air conditioning"
    ]):

        if any(word in message for word in [
            "not cooling",
            "not cool",
            "no cooling",
            "hot air",
            "not giving cool",
            "not giving the cool",
            "blowing hot"
        ]):

            return """
🤖 HomeFix AI – Air Conditioner

Problem:
Your air conditioner is running but not providing cool air.

Possible causes:
1. Dirty air filter.
2. Incorrect temperature setting.
3. Outdoor unit may have a problem.
4. Refrigerant level may be low.
5. Airflow may be blocked.
6. Compressor or fan may have a fault.

Safe checks:
• Check that the AC is set to COOL mode.
• Set the temperature lower than the current room temperature.
• Check whether the indoor air filter is very dirty.
• Make sure the air vents are not blocked.
• Check whether the outdoor unit is operating normally.

⚠️ Safety:
Do not open the AC electrical panel or handle refrigerant yourself.

When to call a technician:
If the AC still does not cool after the safe checks, professional inspection is recommended.
"""

        elif any(word in message for word in [
            "not turning on",
            "won't turn on",
            "doesn't turn on",
            "not working",
            "not starting"
        ]):

            return """
🤖 HomeFix AI – Air Conditioner

Problem:
Your AC is not turning on.

Possible causes:
1. Power supply problem.
2. Remote-control batteries may be weak.
3. Circuit breaker may be switched off.
4. AC may have an internal fault.

Safe checks:
• Check whether the AC has power.
• Check the remote-control batteries.
• Check the circuit breaker.
• Try turning the AC on using its physical power button if available.

⚠️ Do not open the electrical panel.

If the AC still does not turn on, contact a qualified technician.
"""

        else:

            return """
🤖 HomeFix AI – Air Conditioner

I understand that you are having a problem with your AC.

Please check:
• Is the AC turning on?
• Is it cooling?
• Is it blowing hot air?
• Is there unusual noise?
• Is there water leaking?
• Is the airflow weak?

You can describe the exact symptom in your own words and I will suggest possible causes, safe checks, and the next step.

⚠️ Avoid opening electrical parts of the AC yourself.
"""


    # ============================================================
    # TV
    # ============================================================

    if any(word in message for word in [
        "tv", "television"
    ]):

        if any(word in message for word in [
            "black screen",
            "no display",
            "screen is black",
            "not displaying",
            "display not working"
        ]):

            return """
🤖 HomeFix AI – Television

Problem:
The TV is powered on but the screen is not displaying properly.

Possible causes:
1. Incorrect input source selected.
2. Loose HDMI or other cable.
3. Set-top box problem.
4. TV display problem.
5. Power or internal hardware issue.

Safe checks:
• Check whether the TV is powered on.
• Check the selected input/source.
• Reconnect HDMI cables.
• Try another input if available.
• Restart the TV.

If the screen remains black, professional inspection may be required.
"""

        return """
🤖 HomeFix AI – Television

I understand that you are having a TV problem.

Please describe what you see:
• Black screen
• No sound
• No power
• No channels
• Screen flickering
• Remote not working
• HDMI/input problem

I can then suggest possible causes and safe checks.
"""


    # ============================================================
    # REFRIGERATOR
    # ============================================================

    if any(word in message for word in [
        "fridge", "refrigerator"
    ]):

        if any(word in message for word in [
            "not cooling",
            "not cold",
            "not getting cold",
            "warm"
        ]):

            return """
🤖 HomeFix AI – Refrigerator

Problem:
Your refrigerator is not cooling properly.

Possible causes:
1. Temperature setting is incorrect.
2. Air vents are blocked.
3. Condenser area may need cleaning.
4. Door may not be closing properly.
5. Cooling system may have a fault.

Safe checks:
• Check the temperature setting.
• Make sure air vents inside are not blocked.
• Check that the refrigerator door closes properly.
• Avoid overloading the refrigerator.
• Check for unusual noises.

⚠️ Do not attempt to repair the compressor or refrigerant system yourself.

If cooling does not return, contact a qualified technician.
"""

        return """
🤖 HomeFix AI – Refrigerator

Please describe the refrigerator problem.

Examples:
• Refrigerator is not cooling.
• Freezer is not freezing.
• Refrigerator is making noise.
• Water is leaking.
• Ice is not forming.
• Refrigerator is not turning on.
"""


    # ============================================================
    # WASHING MACHINE
    # ============================================================

    if any(word in message for word in [
        "washing machine", "washer"
    ]):

        if any(word in message for word in [
            "noise", "making noise", "sound", "vibration"
        ]):

            return """
🤖 HomeFix AI – Washing Machine

Problem:
Your washing machine is making unusual noise or vibrating.

Possible causes:
1. Uneven load.
2. Machine is not level.
3. Object may be trapped inside.
4. Internal component may have a fault.

Safe checks:
• Stop the machine.
• Check whether clothes are distributed evenly.
• Make sure the machine is standing level.
• Check for visible objects around the drum.

If the noise continues, professional inspection is recommended.
"""

        return """
🤖 HomeFix AI – Washing Machine

I can help troubleshoot your washing machine.

Common problems include:
• Not starting
• Not filling with water
• Not draining
• Not spinning
• Making noise
• Excessive vibration
• Water leakage

Describe the exact problem and I will provide troubleshooting steps.
"""


    # ============================================================
    # CEILING FAN
    # ============================================================

    if any(word in message for word in [
        "fan", "ceiling fan"
    ]):

        if any(word in message for word in [
            "slow",
            "slowly",
            "low speed",
            "running slowly"
        ]):

            return """
🤖 HomeFix AI – Ceiling Fan

Problem:
Your ceiling fan is running slowly.

Possible causes:
1. Speed regulator problem.
2. Capacitor may be weak.
3. Low voltage.
4. Motor may require servicing.
5. Mechanical resistance or dust buildup.

Safe checks:
• Try another speed setting.
• Check whether other electrical appliances are working normally.
• Turn the fan off if it becomes unusually hot or makes abnormal sounds.

⚠️ Do not open electrical wiring or the motor yourself.

If the problem continues, contact an electrician.
"""

        return """
🤖 HomeFix AI – Ceiling Fan

I can help with your fan problem.

Common problems:
• Fan running slowly
• Fan not starting
• Fan making noise
• Fan wobbling
• Fan stopping suddenly
• Fan speed changing

Please describe what the fan is doing.
"""


    # ============================================================
    # LIGHT / BULB
    # ============================================================

    if any(word in message for word in [
        "light", "bulb", "tube light"
    ]):

        return """
🤖 HomeFix AI – Light / Electrical

Possible causes:
1. Bulb may be damaged.
2. Switch may have a problem.
3. Power supply may be interrupted.
4. Wiring or fitting may have a fault.

Safe checks:
• Check whether other lights are working.
• If safe, check whether the switch is ON.
• Check whether the bulb is visibly damaged.

⚠️ Do not touch exposed wires or electrical terminals.

If the problem continues, contact a qualified electrician.
"""


    # ============================================================
    # GEYSER / WATER HEATER
    # ============================================================

    if any(word in message for word in [
        "geyser", "water heater", "heater"
    ]):

        return """
🤖 HomeFix AI – Geyser / Water Heater

Possible causes:
1. Power supply problem.
2. Incorrect temperature setting.
3. Heating element problem.
4. Thermostat problem.
5. Water supply issue.

Safe checks:
• Check the power indicator.
• Check the temperature setting.
• Make sure the water supply is available.
• Check for visible leakage.

⚠️ Do not open the electrical cover or touch internal wiring.

If the geyser is still not working, contact a qualified technician.
"""


    # ============================================================
    # WATER LEAK
    # ============================================================

    if any(word in message for word in [
        "water leaking",
        "leak",
        "leaking",
        "pipe",
        "tap leaking",
        "water leakage"
    ]):

        return """
🤖 HomeFix AI – Water Leakage

Problem:
You appear to have a water leakage problem.

Possible causes:
1. Loose connection.
2. Damaged pipe.
3. Worn-out seal.
4. Faulty tap or valve.
5. Blocked or damaged plumbing component.

Safe checks:
• Identify where the water is coming from.
• If possible, close the nearby water valve.
• Keep electrical appliances away from water.

⚠️ If water is near electrical wiring or sockets, switch off power from a safe location and get professional help.

A plumber may be required if the leakage continues.
"""


    # ============================================================
    # ELECTRICAL SOCKET
    # ============================================================

    if any(word in message for word in [
        "socket", "plug point", "electrical outlet",
        "sparking", "spark", "electric shock"
    ]):

        return """
🤖 HomeFix AI – Electrical Safety

⚠️ This may involve an electrical safety issue.

Possible causes:
• Loose connection.
• Damaged socket.
• Overloaded circuit.
• Damaged appliance plug.
• Wiring fault.

Safe action:
1. Stop using the socket.
2. Do not touch exposed wires.
3. Keep water away from the area.
4. If safe to do so, switch off the relevant circuit from the electrical panel.

⚠️ Do not attempt electrical repair yourself.

Contact a qualified electrician, especially if there is sparking, burning smell, smoke, or electric shock.
"""


    # ============================================================
    # MICROWAVE
    # ============================================================

    if any(word in message for word in [
        "microwave", "microwave oven"
    ]):

        return """
🤖 HomeFix AI – Microwave

Please describe the exact problem.

Common problems include:
• Microwave not turning on
• Food not heating
• Turntable not rotating
• Unusual noise
• Sparks inside
• Door not closing properly

⚠️ Do not open a microwave yourself because internal components can retain dangerous electrical energy even when unplugged.

For sparks, smoke, burning smell, or electrical problems, stop using it and contact a qualified technician.
"""


    # ============================================================
    # WATER / PLUMBING
    # ============================================================

    if any(word in message for word in [
        "water", "plumbing", "drain", "drainage"
    ]):

        return """
🤖 HomeFix AI – Plumbing

I can help identify common household plumbing problems.

Please describe:
• Where the problem is occurring.
• Whether water is leaking, blocked, or not flowing.
• Whether the problem is continuous or occasional.

Safe checks may include checking visible connections and nearby valves.

If there is major leakage or water near electrical equipment, seek professional help immediately.
"""


    # ============================================================
    # GENERIC / UNKNOWN HOUSEHOLD PROBLEM
    # ============================================================

    return """
🤖 HomeFix AI

I can help troubleshoot household problems, even if the exact problem is not listed in my examples.

I understand that you have described:

""" + message + """

To analyze it properly, please tell me:

1. What household appliance, device, room, or system is affected?
2. What exactly is happening?
3. When did the problem start?
4. Is there any unusual sound, smell, heat, smoke, water leakage, or error message?
5. What happened immediately before the problem started?

I will then provide:

• Possible causes
• Safe checks you can perform
• Warning signs
• Recommended next steps
• When professional help is required

⚠️ For electrical, gas, fire, or other dangerous problems, avoid opening or repairing the equipment yourself.
"""