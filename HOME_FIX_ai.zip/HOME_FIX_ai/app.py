from flask import Flask, render_template, request, jsonify
from chatbot import get_homefix_response

app = Flask(__name__)


# -------------------------------------------------
# HOME PAGE
# -------------------------------------------------

@app.route("/")
def home():
    return render_template("index.html")


# -------------------------------------------------
# CHATBOT PAGE
# -------------------------------------------------

@app.route("/chatbot")
def chatbot():
    return render_template("chatbot.html")


# -------------------------------------------------
# CHAT API
# -------------------------------------------------

@app.route("/chat", methods=["POST"])
def chat():

    data = request.get_json()

    if not data:
        return jsonify({
            "response": "Please enter a household problem."
        })

    message = data.get("message", "").strip()

    if not message:
        return jsonify({
            "response": "Please enter a household problem."
        })

    response = get_homefix_response(message)

    return jsonify({
        "response": response
    })

# -------------------------------------------------
# trouble shoot
# -------------------------------------------------

@app.route("/troubleshooting")
def troubleshooting():
    return render_template("troubleshooting.html")

# -------------------------------------------------
# Service
# -------------------------------------------------

@app.route("/service", methods=["GET", "POST"])
def service():

    if request.method == "POST":

        name = request.form.get("name")
        phone = request.form.get("phone")
        problem = request.form.get("problem")
        description = request.form.get("description")
        address = request.form.get("address")

        print("================================")
        print("NEW SERVICE REQUEST")
        print("Name:", name)
        print("Phone:", phone)
        print("Problem:", problem)
        print("Description:", description)
        print("Address:", address)
        print("================================")

        return """
        <script>
            alert("Service request submitted successfully!");
            window.location.href = "/service";
        </script>
        """

    return render_template("service.html")

# -------------------------------------------------
# RUN APPLICATION
# -------------------------------------------------

if __name__ == "__main__":
    app.run(debug=True)